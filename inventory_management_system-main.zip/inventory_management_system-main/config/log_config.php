<?php
// Logging configuration
return [
    'log_file' => __DIR__ . '/../logs/app.log',
    'log_level' => 'debug', // Options: 'debug', 'info', 'warning', 'error'
];
?>
