## Credentials for Login

### Admin Login with inital data: 
- **Username:** `admin123`
- **Password:** `admin123`
### Admin Login without inital data:
- **Username:** `Group_42_admin`
- **Password:** `Group_42_admin`

### Customer Login with inital data:
- **Username:** `user2`
- **Password:** `user2`
### Customer Login without inital data:
- **Username:** `Group_42_user`
- **Password:** `Group_42_user`

## Database Setup

To set up the database, use the following SQL file:
- **SQL database creation:** `create a new database in phpmyadmin name the database inventory_management_system`
- **SQL file:** `then export inventory_management_system.sql on the newly created inventory_management_system database`

## Routes
- **homepage:** `http://localhost/inventory_management_system/public/index.php`
