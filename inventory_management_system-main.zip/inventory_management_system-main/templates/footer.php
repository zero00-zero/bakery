<footer>
        <p>&copy; <?php echo date("Y"); ?> Cake Bake Shop. All rights reserved.</p>
    </footer>
</body>
</html>
